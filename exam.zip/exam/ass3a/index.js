//https://stackoverflow.com/questions/10434001/static-files-with-express-js

var express = require('express');
var app = express();
var path = require('path');

//app.use(express.static(__dirname)); // Current directory is root
app.use(express.static(path.join(__dirname, 'public'))); //  "public" off of current is root

app.get("/contact",function(req,res)
{
    res.sendFile(__dirname+"/public/contact.html");
})

app.get("/admin",function(req,res)
{
    res.sendFile(__dirname+"/public/admin.html");
})

app.listen(4000);
console.log('Listening on port 4000');
