<?php

$data = $_POST['studentData'];
echo $data;
?>